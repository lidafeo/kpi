create definer = root@localhost view view1 as
select `kpi`.`positions`.`position`          AS `position`,
       `kpi`.`users`.`name`                  AS `name_user`,
       `kpi`.`kpi`.`name`                    AS `name_kpi`,
       `kpi`.`uservalues`.`value`            AS `value`,
       `kpi`.`balls`.`ball`                  AS `ball`,
       `kpi`.`kpi`.`indicator_sum`           AS `indicator_sum`,
       `kpi`.`uservalues`.`number_criterion` AS `number_criterion_u`,
       `kpi`.`criterions`.`number_criterion` AS `number_criterion_c`,
       `kpi`.`criterions`.`start_val`        AS `start_val`,
       `kpi`.`criterions`.`final_val`        AS `final_val`,
       `kpi`.`kpi`.`type`                    AS `type`,
       `kpi`.`uservalues`.`date`             AS `date`,
       `kpi`.`kpi`.`count_criterion`         AS `count_criterion`,
       `kpi`.`uservalues`.`start_date`       AS `start_date`,
       `kpi`.`uservalues`.`finish_date`      AS `finish_date`,
       `kpi`.`kpi`.`section`                 AS `section`,
       `kpi`.`kpi`.`subtype`                 AS `subtype`,
       `kpi`.`kpi`.`number`                  AS `number`,
       `kpi`.`users`.`login`                 AS `login`,
       `kpi`.`uservalues`.`id`               AS `id_u`
from (((((`kpi`.`users` join `kpi`.`uservalues` on (`kpi`.`uservalues`.`login_user` = `kpi`.`users`.`login`)) join `kpi`.`kpi` on (`kpi`.`kpi`.`name` = `kpi`.`uservalues`.`name_kpi`)) join `kpi`.`criterions` on (
        `kpi`.`criterions`.`name_kpi` = `kpi`.`uservalues`.`name_kpi` and `kpi`.`criterions`.`number_criterion` =
                                                                          `kpi`.`uservalues`.`number_criterion`)) join `kpi`.`positions` on (`kpi`.`positions`.`position` = `kpi`.`users`.`position`))
         join `kpi`.`balls` on (`kpi`.`criterions`.`id` = `kpi`.`balls`.`id_criterion` and
                                `kpi`.`balls`.`position` = `kpi`.`positions`.`position`))
where `kpi`.`positions`.`number_group` is not null
  and `kpi`.`uservalues`.`valid` = 1;

