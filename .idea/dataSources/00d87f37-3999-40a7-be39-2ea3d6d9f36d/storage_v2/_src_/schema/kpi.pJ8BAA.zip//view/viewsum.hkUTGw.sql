create definer = root@localhost view viewsum as
select `view1`.`name_kpi`             AS `name_kpi`,
       `view1`.`login`                AS `login`,
       `view1`.`start_val`            AS `start_val`,
       `view1`.`final_val`            AS `final_val`,
       count(distinct `view1`.`id_u`) AS `cou`,
       `view1`.`number_criterion_u`   AS `number_criterion_u`,
       max(`view1`.`date`)            AS `md`
from `kpi`.`view1`
where `view1`.`indicator_sum` = 1
  and `view1`.`number_criterion_u` = `view1`.`number_criterion_c`
group by `view1`.`name_kpi`, `view1`.`login`, `view1`.`number_criterion_u`
having `cou` >= `view1`.`start_val`
   and (`view1`.`final_val` is null or `cou` <= `view1`.`final_val`);

