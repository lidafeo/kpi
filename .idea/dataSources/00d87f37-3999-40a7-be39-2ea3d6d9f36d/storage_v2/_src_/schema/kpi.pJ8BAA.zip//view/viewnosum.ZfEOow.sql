create definer = root@localhost view viewnosum as
select `view1`.`position`    AS `position`,
       `view1`.`name_user`   AS `name_user`,
       `view1`.`name_kpi`    AS `name_kpi`,
       `view1`.`ball`        AS `ball`,
       `view1`.`date`        AS `date`,
       `view1`.`login`       AS `login`,
       `view1`.`start_date`  AS `start_date`,
       `view1`.`finish_date` AS `finish_date`
from `kpi`.`view1`
where `view1`.`indicator_sum` = 0
  and `view1`.`start_val` <= `view1`.`value`
  and (`view1`.`final_val` >= `view1`.`value` or `view1`.`final_val` is null);

